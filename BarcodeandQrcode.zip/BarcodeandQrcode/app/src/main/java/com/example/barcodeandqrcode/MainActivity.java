package com.example.barcodeandqrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

import static android.media.tv.TvContract.Programs.Genres.encode;

public class MainActivity extends AppCompatActivity {
    private EditText edit_code;
    private Button save;
    private ImageView barCode,qrCode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init(){
        edit_code=findViewById(R.id.edit_code);
        barCode=findViewById(R.id.bar_code);
        qrCode=findViewById(R.id.qr_code);
        save=findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCode();
            }
        });
    }
    private void getCode(){
        try {
            qrcode();
            barcode();
        }
        catch (Exception e){
            e.printStackTrace();

        }
    }
    MultiFormatWriter multiFormatWriter= new MultiFormatWriter();
    public void qrcode() throws WriterException {
        String finaldata = Uri.encode(String.valueOf(edit_code), "utf-8");

        BitMatrix bm = multiFormatWriter.encode(finaldata, BarcodeFormat.QR_CODE,200, 200);
        Bitmap ImageBitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888);

        for (int i = 0; i < 200; i++) {//width
            for (int j = 0; j < 200; j++) {//height
                ImageBitmap.setPixel(i, j, bm.get(i, j) ? Color.BLACK: Color.WHITE);
            }
        }

        if (ImageBitmap != null) {
            qrCode.setImageBitmap(ImageBitmap);
        } else {
            Toast toast=Toast. makeText(getApplicationContext(),"QR CODE",Toast. LENGTH_SHORT);
            toast. setMargin(50,50);
            toast. show();
        }
    }
    public void barcode() throws WriterException {
        String finaldata = Uri.encode(String.valueOf(edit_code), "utf-8");

        BitMatrix bm = multiFormatWriter.encode(finaldata, BarcodeFormat.CODE_128,250, 50);
        Bitmap ImageBitmap = Bitmap.createBitmap(250, 50, Bitmap.Config.ARGB_8888);

        for (int i = 0; i < 250; i++) {//width
            for (int j = 0; j < 50; j++) {//height
                ImageBitmap.setPixel(i, j, bm.get(i, j) ? Color.BLACK: Color.WHITE);
            }
        }

        if (ImageBitmap != null) {
            barCode.setImageBitmap(ImageBitmap);
        } else {
            Toast toast=Toast. makeText(getApplicationContext(),"BARCODE",Toast. LENGTH_SHORT);
            toast. setMargin(50,50);
            toast. show();
        }
    }


}